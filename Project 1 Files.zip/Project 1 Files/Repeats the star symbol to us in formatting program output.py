/*
 * Returns a string of length n, each character a c.
For example, nCharString(5, *) should return "*****"
 *
 * @param n string length, >=0
 * @return string of n c's
 */
string nCharString(size_t n, char c) {

    //intialising the empty string str
    string str = "";
    
    //Forming the output string
    for(size_t i =0; i<n; i++){
        str += c;
    }

    //returning the string
    return str;
}
