#include <iostream>
#include <string>
#include <cmath> 
#include <iomanip> 
using namespace std;
/**
 * Formats a number as 2 digits, with a leading 0 if needed
 *
 * @param n number to format, assumed between 0 and 59, inclusive
 * @return two digit string representation of number
 */
string nCharString(size_t n, char c) {
   string str = ""; // string to return
   for (size_t i = 0; i < n; i++) { // for the desired length
      str += c; // add character to string
   } // end for
   return str; // return string
} // end nCharString() function}
int main() {
   unsigned int n;
   cin >> n;
   cout << twoDigitString(n);
   return 0;
}