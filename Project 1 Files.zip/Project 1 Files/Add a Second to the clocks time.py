/**
 * Adds one minute
 */
void addOneMinute() {
/**assume you have working getMinute(), setMinute (m), and addOneHour ()
 * Feel free to change these in your program, but for now please get things to work with
 * these function signatures.
 * if getMinute() is between 0 and 58 inclusive, add 1 and setMinute() to the new value
 * if getMinute() is 59 the minutes must be set to 0 and you must call addOneHour () * test will set hours and minutes to 0, then addOneMinute 60 times
 */
   if (getMinute() < 59) { // if minutes is less than 59
        setMinute(getMinute() + 1); // add 1 to minutes
   } 
   else { // if minutes is 59
        setMinute(0); // set minutes to 0
        addOneHour(); // add one hour
   } // end if
} // end addOneMinute() function