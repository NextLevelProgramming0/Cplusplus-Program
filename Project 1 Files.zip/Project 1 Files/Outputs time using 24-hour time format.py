/**
 * Formats the time in am/pm format
 * 
 * @param h, hours 0 to 23
 * @param m, minutes 0 to 59
 * @param s, seconds 0 to 59
 * 
 * @return hh:mm:ss A M or hh:mm:ss P M where hh is between 01 and 12, inclusive
 */
string formatTime24 (unsigned int h, unsigned int m, unsigned int s) {
    string str = ""; // string to return
    str += twoDigitString(h) + ":" + twoDigitString(m) + ":" + twoDigitString(s); // add time to string
    return str; // return string
} // end formatTime24() function