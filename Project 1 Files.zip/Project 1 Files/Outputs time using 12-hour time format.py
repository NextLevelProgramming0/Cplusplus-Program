/**
 * Formats the time in am/pm format
 * 
 * @param h, hours 0 to 23
 * @param m, minutes 0 to 59
 * @param s, seconds 0 to 59
 * 
 * @return hh:mm:ss A M or hh:mm:ss P M where hh is between 01 and 12, inclusive
 */
string formatTime12 (unsigned int h, unsigned int m, unsigned int s) {
   string str = ""; // string to return
   if (h == 0) { // if hour is 0
      str += "12:"; // add "12:"
   } 
   else if (h < 12) { // if hour is less than 12
      str += twoDigitString(h) + ":"; // add hour to the string
   } 
   else { // if hour is greater than 12
       str += twoDigitString(h - 12) + ":"; // add hour to the string
   } // end if
   str += twoDigitString(m) + ":"; // add minutes to the string
   str += twoDigitString(s); // add seconds to the string
   if (h < 12) { // if hour is less than 12
      str += " A M"; // add " A M"
   } 
   else { // if hour is greater than 12
      str += " P M"; // add " P M"
   } // end if
   return str; // return string
} // end formatTime12() function