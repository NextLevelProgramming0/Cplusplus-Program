/**
* Gets menu choice 1 through maxChoice, inclusive
*
* @param maxChoice, maximum choice index, a number between 2 and 9, inclusive
* @return the first legal choice input, could be 1 through maxChoice, inclusive
*/
unsigned int getMenuChoice (unsigned int maxChoice) {
   unsigned int choice = 0; // choice to return
   while (choice < 1 || choice > maxChoice) { // while choice is not between 1 and maxChoice, inclusive
      cout << "Enter your choice: "; // prompt user for choice
      cin >> choice; // get choice
   } // end while
   return choice; // return choice
} // end getMenuChoice() function