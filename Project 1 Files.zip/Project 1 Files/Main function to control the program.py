/**
 * Adds one hour
 */
void addOneHour() {
/** Assume you have a working getHour () and setHour (h)
 * if getHour () is between 0 and 22 inclusive, add 1 and setHour () to that
 * if getHour () is 23 the next value for hour is so setHour () to that
 * test will check values of hours from 0 to 23 from getHour ()
 */
   if (getHour() < 23) { // if hours is less than 23
        setHour(getHour() + 1); // add 1 to hours
   } 
   else { // if hours is 23
        setHour(0); // set hours to 0
   } // end if
} // end addOneHour() functionn