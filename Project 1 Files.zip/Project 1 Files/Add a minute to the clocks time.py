/**
 *Adds one second
 */
void addOneSecond () {
/** assume you have working getSecond (), setSecond(s), and addOneMinute()
 *addOneMinute will take care of the hours if necessary * if getSecond () is between 0 and 58 inclusive, add 1 and setSecond ()
 * if getSecond () is 59, seconds wrap around to and you need to call addOneMinute()
 * test will set minutes to 4 and seconds to 0, then addOneSecond 60 times
 */
   if (getSecond() < 59) { // if seconds is less than 59
      setSecond(getSecond() + 1); // add 1 to seconds
   } 
   else { // if seconds is 59
      setSecond(0); // set seconds to 0
      addOneMinute(); // add one minute
   } // end if
} // end addOneSecond() function