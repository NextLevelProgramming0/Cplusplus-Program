/**
 * Prints menu
 * 
 * @param strings [], nonempty array of choices
 * @param width, width of each line will be comfortably bigger than the longest string
 * 
 */
void printMenu(char* strings [], unsigned int numStrings, unsigned char width) {
   for (unsigned int i = 0; i < numStrings; i++) { // for each string
      cout << strings[i] << nCharString(width - strlen(strings[i]), ' ') << endl; // print string and spaces
   } // end for
} // end printMenu() function
