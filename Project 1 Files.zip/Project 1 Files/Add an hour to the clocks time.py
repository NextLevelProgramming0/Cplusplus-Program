/**
 * repeats getting the user's choice and taking the appropriate action until the user chooses 4 for exit
 */
void mainMenu(){
    /** You may assume you have a working getMenuChoice (n), addOneHour (), addOneMinute(), and addOneSecond().
     * The test will hit 1\n2\n2\n3\n3\n3\n4\n, and expect the adding functions to be called the right number of times.
     * getMenuChoice (4) will handle the input and return 1, 2, 3, or 4.
     */
   unsigned int choice = 0; // choice to return
   while (choice != 4) { // while choice is not 4
      choice = getMenuChoice(4); // get choice
      switch (choice) { // switch on choice
         case 1: // if choice is 1
            addOneHour(); // add one hour
            break; // break out of switch
         case 2: // if choice is 2
            addOneMinute(); // add one minute
            break; // break out of switch
         case 3: // if choice is 3
            addOneSecond(); // add one second
            break; // break out of switch
         case 4: // if choice is 4
            break; // break out of switch
       }// end switch
       displayClocks(getHour(), getMinute(), getSecond()); // display clocks
   }// end while
} // end mainMenu() function